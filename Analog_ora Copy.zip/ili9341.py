import time
import framebuf
from machine import Pin

class ILI9341:
    def __init__(self, spi, cs, dc, rst, w=240, h=320):
        self.spi = spi
        self.cs = cs
        self.dc = dc
        self.rst = rst
        self.width = w
        self.height = h
        self.cs.init(Pin.OUT, value=1)
        self.dc.init(Pin.OUT, value=0)
        self.rst.init(Pin.OUT, value=1)
        self.reset()
        self.init_display()
        # 16-bites RGB565 színpuffer létrehozása
        self.buf = bytearray(self.width * self.height * 2)
        self.fb = framebuf.FrameBuffer(self.buf, self.width, self.height, framebuf.RGB565)

    def reset(self):
        self.rst.value(0)
        time.sleep_ms(50)
        self.rst.value(1)
        time.sleep_ms(50)

    def write_cmd(self, cmd):
        self.dc.value(0)
        self.cs.value(0)
        self.spi.write(bytearray([cmd]))
        self.cs.value(1)

    def write_data(self, data):
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(data)
        self.cs.value(1)

    def init_display(self):
        for cmd, data in [
            (0xEF, b'\x03\x80\x02'),
            (0xCF, b'\x00\xC1\x30'),
            (0xED, b'\x64\x03\x12\x81'),
            (0xE8, b'\x85\x00\x78'),
            (0xCB, b'\x39\x2C\x00\x34\x02'),
            (0xF7, b'\x20'),
            (0xEA, b'\x00\x00'),
            (0xC0, b'\x23'),
            (0xC1, b'\x10'),
            (0xC5, b'\x3E\x28'),
            (0xC7, b'\x86'),
            (0x36, b'\x48'), # Álló mód (Portrait)
            (0x3A, b'\x55'), # 16-bites színmód
            (0xB1, b'\x00\x18'),
            (0xB6, b'\x08\x82\x27'),
            (0xF2, b'\x00'),
            (0x26, b'\x01'),
            (0xE0, b'\x0F\x31\x2B\x0C\x0E\x08\x4E\xF1\x37\x07\x10\x03\x0E\x09\x00'),
            (0xE1, b'\x00\x0E\x14\x03\x11\x07\x31\xC1\x48\x08\x0F\x0C\x31\x36\x0F'),
            (0x11, b''),
        ]:
            self.write_cmd(cmd)
            if data: self.write_data(data)
        time.sleep_ms(120)
        self.write_cmd(0x29) # Kijelző bekapcsolása

    def show(self):
        self.write_cmd(0x2A) # Oszlopcím beállítása
        self.write_data(bytearray([0, 0, (self.width-1)>>8, (self.width-1)&0xFF]))
        self.write_cmd(0x2B) # Sorfejléc beállítása
        self.write_data(bytearray([0, 0, (self.height-1)>>8, (self.height-1)&0xFF]))
        self.write_cmd(0x2C) # Írás a memóriába
        
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(self.buf)
        self.cs.value(1)
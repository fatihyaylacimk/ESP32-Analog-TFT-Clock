import network
import time
import utime
import ntptime
import math
from machine import Pin, SPI
import ili9341

# --- Színkonstansok (RGB565 16-bit) ---
BACKGROUND = 0xF7F9  # Nagyon világos szürke háttér
CLOCK_FACE = 0xFFFF  # Tiszta fehér számlap
BLACK      = 0x0000
RED        = 0xF800  # Másodpercmutató
DARKBLUE   = 0x011F  # Percmutató
DARKGRAY   = 0x5AEB  # Keret és órajelzések

# --- Geometriai méretek (240x320-as álló kijelzőhöz) ---
WIDTH = 240
HEIGHT = 320
CENTER_X = 120
CENTER_Y = 160
RADIUS = 105

# --- Hardver inicializálása ---
spi = SPI(0, baudrate=40000000, sck=Pin(18), mosi=Pin(19))
display = ili9341.ILI9341(spi, cs=Pin(17), dc=Pin(16), rst=Pin(20), w=WIDTH, h=HEIGHT)
fb = display.fb  # Közvetlen elérés a grafikus funkciókhoz

# --- Wi-Fi és Idő szinkronizálás ---
def init_network():
    fb.fill(BLACK)
    fb.text("WiFi csatlakozas...", 10, 10, CLOCK_FACE)
    display.show()
    
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect('Wokwi-GUEST', '')
    while not wlan.isconnected():
        time.sleep(0.5)
        
    fb.text("Sikeres halozat!", 10, 30, CLOCK_FACE)
    fb.text("Ido szinkronizalas...", 10, 50, CLOCK_FACE)
    display.show()
    
    try:
        ntptime.settime()
        fb.text("Kesz!", 10, 70, CLOCK_FACE)
    except:
        fb.text("NTP Hiba!", 10, 70, RED)
    display.show()
    time.sleep(1.5)

# Matematikailg pontos körívet rajzoló függvény vonalakból
def draw_clock_circle(cx, cy, r, color):
    steps = 60
    for i in range(steps):
        a1 = math.radians(i * (360 / steps))
        a2 = math.radians((i + 1) * (360 / steps))
        x1 = int(cx + math.cos(a1) * r)
        y1 = int(cy + math.sin(a1) * r)
        x2 = int(cx + math.cos(a2) * r)
        y2 = int(cy + math.sin(a2) * r)
        fb.line(x1, y1, x2, y2, color)

# Hálózat indítása
init_network()

# Magyarországi időzóna eltolás (pl. Nyári idő UTC+2: 2 * 3600 másodperc)
UTC_OFFSET = 2 * 3600

while True:
    local_epoch = utime.time() + UTC_OFFSET
    tm = utime.localtime(local_epoch)
    
    h = tm[3] % 12
    m = tm[4]
    s = tm[5]
    
    # 1. Háttér tisztítása
    fb.fill(BACKGROUND)
    
    # 2. Számlap alapja és kettős kerete
    # Belül fehér körlapot építünk fel koncentrikus körökkel a kitöltéshez
    for r in range(RADIUS):
        draw_clock_circle(CENTER_X, CENTER_Y, r, CLOCK_FACE)
    draw_clock_circle(CENTER_X, CENTER_Y, RADIUS, BLACK)
    draw_clock_circle(CENTER_X, CENTER_Y, RADIUS + 1, DARKGRAY)
    
    # 3. Számok felírása (1-től 12-ig)
    num_radius = RADIUS - 18
    for i in range(1, 13):
        angle = math.radians((i * 30) - 90)
        num_x = CENTER_X + math.cos(angle) * num_radius
        num_y = CENTER_Y + math.sin(angle) * num_radius
        
        text_str = str(i)
        # Karakterenkénti tökéletes középre igazítás (egy karakter 8x8 pixel a framebuf-ban)
        corr_x = int(num_x - (len(text_str) * 8) / 2)
        corr_y = int(num_y - 4)
        
        fb.text(text_str, corr_x, corr_y, BLACK)
        
    # 4. Mutatók végpontjainak kiszámítása
    sec_angle = math.radians((s * 6) - 90)
    min_angle = math.radians((m * 6 + s * 0.1) - 90)
    hour_angle = math.radians((h * 30 + m * 0.5) - 90)
    
    # Mutatók hosszai
    sec_len = RADIUS - 10
    min_len = RADIUS - 22
    hour_len = RADIUS - 45
    
    sec_x = int(CENTER_X + math.cos(sec_angle) * sec_len)
    sec_y = int(CENTER_Y + math.sin(sec_angle) * sec_len)
    
    min_x = int(CENTER_X + math.cos(min_angle) * min_len)
    min_y = int(CENTER_Y + math.sin(min_angle) * min_len)
    
    hour_x = int(CENTER_X + math.cos(hour_angle) * hour_len)
    hour_y = int(CENTER_Y + math.sin(hour_angle) * hour_len)
    
    # 5. Mutatók kirajzolása (Vastagítás pixel-eltolásos párhuzamos vonalakkal)
    # Óramutató (Legvastagabb, fekete)
    fb.line(CENTER_X, CENTER_Y, hour_x, hour_y, BLACK)
    fb.line(CENTER_X + 1, CENTER_Y, hour_x + 1, hour_y, BLACK)
    fb.line(CENTER_X, CENTER_Y + 1, hour_x, hour_y + 1, BLACK)
    
    # Percmutató (Közepes vastagságú, sötétkék)
    fb.line(CENTER_X, CENTER_Y, min_x, min_y, DARKBLUE)
    fb.line(CENTER_X + 1, CENTER_Y, min_x + 1, min_y, DARKBLUE)
    
    # Másodpercmutató (Vékony, piros)
    fb.line(CENTER_X, CENTER_Y, sec_x, sec_y, RED)
    
    # Középső díszítő tengely-pont
    for r in range(4):
        draw_clock_circle(CENTER_X, CENTER_Y, r, BLACK)
        
    # Puffer tartalmának átvitele a fizikai kijelzőre
    display.show()
    
    time.sleep(1)